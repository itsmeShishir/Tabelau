function add(x,y){
    return x+y
}
                                    //same ho jun garepani
const subtract =(x,y) => x-y
const multiply =(x,y) => x*y
const divide =(x,y) => x/y

module.exports = {add, subtract, multiply, divide}    //arko thau use garna lai or arko file ma use garna lai with
                                                        //function name