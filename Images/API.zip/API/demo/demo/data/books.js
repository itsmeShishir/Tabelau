module.exports = [
    {
        "id":1,
        "title": "Rich Dad Poor Dad",
        "author": "Robert Kiwosaki"
    },

    {
        "id":2,
        "title":"One Piece",
        "author":"Eiichiro Oda"
    }
]