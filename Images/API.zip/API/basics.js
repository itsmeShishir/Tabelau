//function add(x,y){
 //   return x+y
//}

//const subtract=(x,y) => {
  //  return x-y
//any non zero value can be true
//}


let x={
    'name':'tanuja',
    'age':20
}

let y=[1,2,3]
console.log(y[1])

y.forEach((item) => item * 2)

y.forEach((item) => {console.log(item * 2)})
console.log(typeof(x))
console.log(x.name)
//console.log(add(2,3))
//console.log(subtract(2,3))

let z=[]
y.forEach((item) => {z.push(item * 2)})
console.log(y)
console.log(z)
