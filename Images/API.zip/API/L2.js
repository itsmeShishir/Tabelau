// how to use library 
const fs=require('fs')
const path=require('path')

// data=fs.readFileSync('./example.txt')
fs.readFile(path.join(__dirname,'./example.txt'),(err,data)=>{
    if(err)console.error(err)
    console.log(data.toString())
})
fs.writeFile(path.join(__dirname,'test.txt'),'Testing Testing ...',(err) => {
    if (err)console.error(err)
    console.log('write done')
})
fs.appendFile(path.join(__dirname, 'test.txt'), '\nGood to be here',(err) => {
    if (err)console.error(err)
    console.log('append done')
})
// console.log(data)
    console.log("Testing ..")

//existing library
// const os=require('os')
// const path=require('path')
// const math=require('./math')  //importing of the another file using its file name or path name
// const {add,subtract,multiply,divide}= require('./math')   //yo ni use garna milxa in place of 4 number

// console.log(add(2,3))
// console.log(subtract(2,3))
// console.log(multiply(2,3))
// console.log(divide(2,3))

//console.log(math.add(2,3))
//console.log(math.subtract(2,3))
//console.log(math.multiply(2,3))
//console.log(math.divide(2,3))

//console.log(os.version())
//console.log(os.type())
//console.log(os.homedir())


//console.log(__dirname)
//console.log(__filename)


//console.log(path.basename(__filename))
//console.log(path.extname(__filename))