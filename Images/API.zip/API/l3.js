const fs=require('fs')
const fsPromises=require('fs').promises
const path=require('path')

//callbach hell
fs.readFile(path.join(__dirname, 'example.txt'),(err,data) =>{
    if(err)console.log(err)
    fs.writeFile('./reply.txt', data, (err) =>{
        if(err)console.log(err)
        fs.appendFile('./reply.txt','\nHello babe',(err) =>{
            if(err)console.log(err)
            fs.rename('./reply.txt', './nenew-reply.txt',(err) =>{
            if(err)console.log(err)
             console.log('rename completed')
        })

        })
       
    })
    
})

console.log('testing testing ...')

//1.Using promises
// fsPromises.readFile('./example.txt','utf-8')
//     .then((data) =>{
//         console.log(data)
//         fsPromises.writeFile('./reply.txt',data)
//         .then(()=>{fsPromises.appendFile('./reply.txt','\nWE are we')

//         .then(()=>{
//             console.log('append complete')
//         }).catch((err)=>console.log(err))

//         })
//         .catch((err)=>console,log(err))
//     })
//     .catch((err)=>{

//     })

//2Async/await
const fileOperations= async()=>{
    try{
    const data=await fsPromises.readFile('./example.txt','utf-8')
    await fsPromises.writeFile('./reply.txt',data)
    await fsPromises.appendFile('./reply.txt','.\nhii tanuja')
    await fsPromises.rename('./reply.txt','await-reply.txt')
    console.log(data)
}catch(error){
    console.log(error)
}
}

fileOperations()

console.log('testing testing ...')
